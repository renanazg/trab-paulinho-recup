package com.example.exercicio2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edLargA, edAltA,edLargB,edAltB;
    TextView tvPer,tvAre;
    Button btCal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edLargA = findViewById(R.id.edLargA);
                edAltA = findViewById(R.id.edAltA);
        edLargB = findViewById(R.id.edLargB);
                edAltB = findViewById(R.id.edAltB);
        tvPer = findViewById(R.id.tvPer);
                tvAre = findViewById(R.id.tvAre);
                btCal = findViewById(R.id.btCal);

                btCal.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Double largA = Double.parseDouble(edLargA.getText().toString());
                        Double altA = Double.parseDouble(edAltA.getText().toString());
                        Double largB = Double.parseDouble(edLargB.getText().toString());
                        Double altB = Double.parseDouble(edAltB.getText().toString());

                        Double area = largA * altA;
                        Double perimetro = largA + altA+ largB+ altB;

                        tvAre.setText(area.toString());
                        tvPer.setText(perimetro.toString());
                    }
                });
    }


}